#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "dados.h"
#include "lista_enc.h"
#include "no.h"
#include "pilha.h"

#define TAM_BUFFER 128

struct dados{
    int pos;
    char *nome;
    int ouro;
    int prata;
    int bronze;
    int total_med;
};


dado_t *cria_dado(int pos, char *nome, int ouro, int prata, int bronze, int total_med)
{
    int tamanho;
    dado_t *x = malloc(sizeof(dado_t));
    if(x == NULL){
        perror("Erro na alocacao dado_t *x:");
        exit(1);
    }

    tamanho = strlen(nome);
    x->nome = malloc(tamanho + 1);
    if(x->nome == NULL){
        perror("Erro na alocacao x->nome: ");
        exit(1);
    }
    strncpy(x->nome, nome, tamanho + 1);
    x->pos = pos;
    x->ouro = ouro;
    x->prata = prata;
    x->bronze = bronze;
    x->total_med = total_med;

    return x;
}


pilha_t *ler_arquivo(char *nome)
{
    FILE *fp = fopen(nome, "r");
        if (fp == NULL){
        perror("Erro em pilha_t: fopen");
        exit(EXIT_FAILURE);
    }

    char buffer_total[TAM_BUFFER];
    char buffer_nome[64];
    int ret;
    int pos, ouro, prata, bronze, total_med;

    pilha_t *pilha = cria_pilha();
    while(fgets(buffer_total, TAM_BUFFER, fp) != NULL){
        ret = sscanf(buffer_total, "%d, %63[^,],%d,%d,%d,%d\n", &pos, buffer_nome, &ouro, &prata, &bronze, &total_med);
        if (ret != 6){
            perror("Quantidade de dados lidos no arquivo:");
            exit(1);
       }
       dado_t *dados;
       dados = cria_dado(pos, buffer_nome, ouro, prata, bronze, total_med);

       push(dados, pilha);

    }
     fclose(fp);
     return pilha;
}


void imprime_dados(pilha_t *pilha)
{
    int i;
    no_t *elemento;
    elemento = topo_pilha(pilha);
    dado_t *dado_temp;
    for(i = 0; i < tamanho_pilha(pilha); i++){
        //elemento = pop(pilha);
        dado_temp = obtem_dado(elemento);
        printf("%2d\t%36s\t%2d\t%2d\t%2d\t%2d\n", dado_temp->pos, dado_temp->nome, dado_temp->ouro, dado_temp->prata, dado_temp->bronze, dado_temp->total_med);
        elemento = obtem_proximo(elemento);
    }
}

void libera_dados(pilha_t *pilha)
{
    while(tamanho_pilha(pilha)){
        no_t *meu_no = pop(pilha);
        dado_t *dado_temp = obtem_dado(meu_no);
        free (dado_temp->nome);
        free(dado_temp);
        free (meu_no);
    }
    libera_pilha(pilha);
}

