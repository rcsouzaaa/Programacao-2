#include <stdio.h>
#include <stdlib.h>

#include "no.h"
#include "lista_enc.h"
#include "pilha.h"


struct pilhas{
    lista_enc_t *dados;
};

pilha_t * cria_pilha()
{
    pilha_t *pilha = malloc(sizeof(pilha_t));

    pilha->dados = cria_lista_enc();
    return pilha;
}

void push(void* dado, pilha_t *pilha)
{
    no_t *no = cria_no(dado);
    add_cabeca(pilha->dados, no);

}

void * pop(pilha_t *pilha)
{
    if (tamanho_pilha(pilha) == 0) {
        fprintf(stderr, "Tamanho maximo da pilha atingido\n");
        exit(EXIT_FAILURE);
    }

    void *dado = remove_cabeca(pilha->dados);
    return dado;
}

void * topo_pilha(pilha_t *pilha)
{
    void *dado = obtem_cabeca(pilha->dados);
    return dado;
}

int tamanho_pilha(pilha_t *pilha)
{
    int tamanho = tamanho_lista(pilha->dados);
    return tamanho;
}

int pilha_vazia(pilha_t *pilha)
{
    if(tamanho_pilha(pilha) == 0 )
        return 1;

    return 0;
}
void libera_pilha(pilha_t *pilha)
{
    if(pilha == NULL){
        fprintf(stderr, "Pilha esta vazia");
        exit(-1);
    }
    libera_lista(pilha->dados);

    free(pilha);
}

void imprime_pilha(pilha_t* fila)
{
    imprime_lista(fila->dados);
}
