#ifndef DADOS_H_INCLUDED
#define DADOS_H_INCLUDED

#include "lista_enc.h"
#include "no.h"
#include "pilha.h"

typedef struct dados dado_t;

pilha_t *ler_arquivo(char *nome);
dado_t *cria_dado(int pos, char *nome, int ouro, int prata, int bronze, int total_med);
void imprime_dados(pilha_t *pilha);
void libera_dados(pilha_t *pilha);

#endif
