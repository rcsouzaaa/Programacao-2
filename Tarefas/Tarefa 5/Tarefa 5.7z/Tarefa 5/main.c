/*                          Tarefa 05
 *
 *    Este programa le os dados do winterGames.csv
 *    organiza em uma estrutuda de dados dentro
 *    de n�s que sao ordenados
 *    e apresenta os dados organizados na tela na maim.c.
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "dados.h"


int main()
{
    pilha_t *pilha;

    pilha = ler_arquivo("winterGames.csv");

    imprime_dados(pilha);

    libera_dados(pilha);

    return 0;
}
